/*!
 * <granvaya-pipeline> — Granvaya knowledge-graph pipeline animation
 * ------------------------------------------------------------------
 * Self-contained custom element. No dependencies, no build step.
 * Shadow DOM, so none of its CSS leaks and none of yours leaks in.
 *
 * USAGE — plain HTML
 *   <script type="module" src="/granvaya-pipeline.js"></script>
 *   <granvaya-pipeline></granvaya-pipeline>
 *
 * USAGE — React
 *   import '/granvaya-pipeline.js';
 *   export const Hero = () => <granvaya-pipeline chrome="minimal" links="keep" />;
 *   (React 19 passes unknown attributes straight through. On React 17/18 use a
 *    ref and set attributes in useEffect, or wrap with @lit/react.)
 *
 * SIZING
 *   The element is display:block and fills its container's width, holding a
 *   1240 x 680 aspect ratio. Put it in any box and it scales. Below roughly
 *   560px wide the small labels stop being legible — use chrome="minimal"
 *   there, or chrome="none" for a pure motion graphic.
 *
 * ATTRIBUTES  (all optional, all live — change them any time)
 *   chrome   "full" (default) | "minimal" (no headline/captions) | "none" (diagram only)
 *   links    "fade" (default) | "keep"  — keep accumulates cross-links so the graph thickens
 *   speed    number, default 1. 0.7 = slower, 1.5 = faster.
 *   paused   boolean attribute — present means frozen
 *
 * BEHAVIOUR
 *   Pauses automatically when scrolled out of view and when the tab is hidden.
 *   Honours prefers-reduced-motion (holds a finished still frame, no motion).
 *   Cleans up every timer and observer on disconnect — safe in React StrictMode.
 *
 * DATA
 *   TREE / KEEP / JUNK below are the demo content. Swap them for real seeded
 *   nodes when the graph API exists; the layout re-solves itself from the data.
 */

const W = 1240, H = 680;
const X1 = 612, X2 = 792, X3 = 986;      // paper / head / thread columns
const TOP = 42, BOT = 612;
const BASE = { x: 556, y: 362 };
const CARD_Y = 336, START_X = -200, GATE_X = 176, IN_X = 378;

/* ---------------- content ---------------- */

const TREE = [
  { paper: 'GS 1', heads: [
    { name: 'Geography · Resources', leaves: [
      { id: 'crit',  label: 'Critical Minerals Supply Chain', adden: 2 },
      { id: 'park',  label: 'UNESCO Geoparks – India',        adden: 0 }]},
    { name: 'History · Indian Culture', leaves: [
      { id: 'indus', label: 'Indus Script – Decipherment',    adden: 1 }], more: 4 }
  ]},
  { paper: 'GS 2', heads: [
    { name: 'Polity · Indian Constitution', leaves: [
      { id: 'priv',   label: 'Right to Privacy – Evolution',  adden: 3 },
      { id: 'creamy', label: 'Creamy Layer for SC/ST',        adden: 1 }]},
    { name: 'Polity · Elections', leaves: [
      { id: 'caste',  label: 'Caste Census',                  adden: 2 }]},
    { name: 'Intl. Relations', leaves: [
      { id: 'ijp',    label: 'India – Japan',                 adden: 1 }], more: 9 }
  ]},
  { paper: 'GS 3', heads: [
    { name: 'Economy · Macroeconomics', leaves: [
      { id: 'loan',   label: 'Loan Pricing – Ext. Benchmark', adden: 0, preset: false },
      { id: 'vda',    label: 'Virtual Digital Assets',        adden: 2 }]},
    { name: 'Environment · Biodiversity', leaves: [
      { id: 'ramsar', label: 'Ramsar Sites – 2026',           adden: 2 },
      { id: 'eia',    label: 'Ex-post-facto Clearance',       adden: 1 }]},
    { name: 'Science & Technology', leaves: [
      { id: 'aisec',  label: 'AI in Internal Security',       adden: 0, preset: false },
      { id: 'rlv',    label: 'RLV Programme',                 adden: 0, preset: false }], more: 12 }
  ]},
  { paper: 'GS 4', heads: [
    { name: 'Ethics · Applied', leaves: [
      { id: 'algo',   label: 'Algorithmic Governance',        adden: 1 }], more: 3 }
  ]}
];

const KEEP = [
  { src:'THE INDIAN EXPRESS · p.13', hl:'RBI proposes new loan interest-rate framework',
    kind:'fresh',    note:'Loan Pricing – Ext. Benchmark', gs:'GS 3 · ECONOMY',     node:'loan',   links:['vda'] },
  { src:'PIB', hl:'Two new wetlands added to the Ramsar list',
    kind:'addendum', note:'Ramsar Sites – 2026',           gs:'GS 3 · ENVIRONMENT', node:'ramsar', links:['crit','eia'] },
  { src:'THE HINDU · p.1', hl:'Supreme Court reads Article 21 into new privacy rules',
    kind:'merge',    note:'Right to Privacy – Evolution',  gs:'GS 2 · POLITY',      node:'priv',   links:['algo','caste'] },
  { src:'PIB', hl:'ISRO validates reusable launch vehicle landing',
    kind:'fresh',    note:'RLV Programme',                 gs:'GS 3 · SCI & TECH',  node:'rlv',    links:['ijp'] },
  { src:'THE HINDU · p.9', hl:'AI drones deployed against left-wing extremism',
    kind:'fresh',    note:'AI in Internal Security',       gs:'GS 3 · SCI & TECH',  node:'aisec',  links:['algo','priv','crit'] },
  { src:'EDITORIAL', hl:'Should algorithms decide welfare eligibility?',
    kind:'addendum', note:'Algorithmic Governance',        gs:'GS 4 · ETHICS',      node:'algo',   links:['priv'] }
];

const JUNK = [
  { src:'SPORT · p.14', hl:'India win the third one-day by six wickets' },
  { src:'CITY · p.5',   hl:'Actor spotted at airport, fans gather' },
  { src:'MARKETS',      hl:'Sensex closes 212 points higher' },
  { src:'NATION · p.7', hl:'Leader calls rival remark "unfortunate"' }
];

const ORDER = [ {t:'k',i:0},{t:'j',i:0},{t:'k',i:1},{t:'k',i:2},{t:'j',i:1},
                {t:'k',i:3},{t:'j',i:2},{t:'k',i:4},{t:'k',i:5},{t:'j',i:3} ];

/* ---------------- styles ---------------- */

const CSS = `
:host{display:block;position:relative;width:100%;
  --navy:#001238;--cyan:#00E0F0;--teal:#00DCC7;--blue:#0395F8;
  --dim:#8FA6D4;--junk:#4A5A7E;--white:#F8FBFF;
  font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Inter,Roboto,Arial,sans-serif}
:host([hidden]){display:none}
*{box-sizing:border-box;margin:0;padding:0}
.frame{position:relative;width:100%;aspect-ratio:${W} / ${H};overflow:hidden;border-radius:18px}
.scaler{position:absolute;top:0;left:0;transform-origin:top left}
.stage{position:relative;width:${W}px;height:${H}px;color:var(--white);background:
  radial-gradient(900px 520px at 70% 46%,rgba(0,224,240,.10),transparent 70%),
  radial-gradient(600px 400px at 12% 62%,rgba(3,149,248,.09),transparent 70%),var(--navy)}
.grid{position:absolute;inset:0;opacity:.3;
  background-image:linear-gradient(rgba(143,166,212,.055) 1px,transparent 1px),
                   linear-gradient(90deg,rgba(143,166,212,.055) 1px,transparent 1px);
  background-size:48px 48px}

/* ---- title: COLLECTION / CONNECTION differ by exactly two letters ---- */
.head{position:absolute;left:36px;top:80px;z-index:6}
.title{font-size:44px;font-weight:800;letter-spacing:-.02em;line-height:1;
  display:flex;align-items:center;gap:14px;white-space:nowrap}
.word{color:#E8F1FD}
.morph{display:inline-grid;vertical-align:baseline}
.morph i{grid-area:1/1;font-style:normal;text-align:center}
.morph .a{color:#6E86B4;animation:gvA 10s ease-in-out infinite}
.morph .b{color:var(--cyan);text-shadow:0 0 26px rgba(0,224,240,.45);
  animation:gvB 10s ease-in-out infinite}
.mark{display:inline-grid;width:30px;height:30px;flex:none}
.mark i{grid-area:1/1;font-style:normal;display:grid;place-items:center;
  width:30px;height:30px;border-radius:50%;font-size:15px;font-weight:700}
.mark .mx{color:#6E86B4;border:1.5px solid rgba(110,134,180,.45);animation:gvA 10s ease-in-out infinite}
.mark .mk{color:var(--navy);background:var(--cyan);animation:gvB 10s ease-in-out infinite}
.rule{position:absolute;left:36px;top:136px;height:2px;width:0;z-index:6;
  background:linear-gradient(90deg,var(--cyan),rgba(0,224,240,0));
  animation:gvRule 10s ease-in-out infinite}
@keyframes gvA{0%,20%{opacity:1}27%,92%{opacity:0}100%{opacity:1}}
@keyframes gvB{0%,20%{opacity:0}27%,92%{opacity:1}100%{opacity:0}}
@keyframes gvRule{0%,22%{width:0}34%,92%{width:272px}100%{width:0}}

.stats{position:absolute;left:36px;top:168px;display:grid;grid-template-columns:1fr 1fr;gap:7px;z-index:6}
.stat{background:rgba(255,255,255,.04);border:1px solid rgba(143,166,212,.14);
  border-radius:9px;padding:7px 10px;min-width:100px}
.stat b{display:block;font-size:17px;font-variant-numeric:tabular-nums;line-height:1.2}
.stat span{font-size:9px;color:var(--dim);letter-spacing:.05em}
.stat.k b{color:var(--teal)}.stat.s b{color:#8497BA}.stat.x b{color:var(--blue)}
.bintext{position:absolute;left:150px;top:578px;width:178px;text-align:center;z-index:5;
  font-size:11px;color:#93A7CC;letter-spacing:.1em;font-weight:700}

:host([chrome="minimal"]) .head,:host([chrome="minimal"]) .rule,
:host([chrome="minimal"]) .bintext{display:none}
:host([chrome="none"]) .head,:host([chrome="none"]) .rule,
:host([chrome="none"]) .bintext,:host([chrome="none"]) .stats{display:none}

.belt{position:absolute;left:-60px;top:430px;width:452px;height:24px;z-index:1;
  background:linear-gradient(180deg,#0d2454,#071a41);border-radius:6px;
  box-shadow:0 10px 30px rgba(0,0,0,.45),inset 0 1px 0 rgba(255,255,255,.08)}
.belt::after{content:"";position:absolute;inset:0;border-radius:6px;
  background:repeating-linear-gradient(90deg,rgba(143,166,212,.2) 0 2px,transparent 2px 28px);
  animation:beltmove 1.4s linear infinite}
@keyframes beltmove{to{background-position:28px 0}}
.roller{position:absolute;top:426px;width:32px;height:32px;border-radius:50%;z-index:1;
  background:conic-gradient(from 0deg,#123069,#0a1f4d,#123069,#0a1f4d);
  border:2px solid rgba(143,166,212,.26);animation:spin 1.4s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.legs{position:absolute;top:454px;height:66px;width:8px;border-radius:4px;z-index:1;
  background:linear-gradient(180deg,#0c2151,#061634)}

.bin{position:absolute;z-index:4;left:176px;top:498px;width:126px;height:70px;
  background:linear-gradient(180deg,#0b1f49,#071534);border:1px solid rgba(143,166,212,.2);
  clip-path:polygon(7% 0,93% 0,83% 100%,17% 100%)}
.binlid{position:absolute;z-index:4;left:168px;top:488px;width:142px;height:9px;border-radius:5px;
  background:#122c61;border:1px solid rgba(143,166,212,.22);transform-origin:left center}

.machine{position:absolute;z-index:5;left:352px;top:250px;width:186px;height:226px;
  background:linear-gradient(180deg,rgba(9,32,82,.97),rgba(4,18,52,.97));
  border:1px solid rgba(0,224,240,.3);border-radius:16px;
  box-shadow:0 18px 50px rgba(0,0,0,.55),inset 0 0 40px rgba(0,224,240,.06)}
.mouth{position:absolute;left:12px;right:12px;top:132px;height:62px;border-radius:8px;
  background:rgba(0,0,0,.38);border:1px solid rgba(143,166,212,.14)}
.scan{position:absolute;left:14px;right:14px;top:134px;height:2px;border-radius:2px;
  background:linear-gradient(90deg,transparent,var(--cyan),transparent);
  box-shadow:0 0 14px rgba(0,224,240,.9);animation:scanmove 1.9s ease-in-out infinite}
@keyframes scanmove{0%,100%{transform:translateY(0)}50%{transform:translateY(56px)}}
.steps{position:absolute;left:13px;right:11px;top:16px;display:grid;gap:17px}
.step{position:relative;display:flex;align-items:center;gap:7px;font-size:8.5px;
  color:var(--dim);font-weight:700;letter-spacing:.03em;transition:color .2s}
.step::after{content:"";position:absolute;left:3px;top:12px;width:1.5px;height:19px;
  background:rgba(143,166,212,.22);transition:background .25s}
.step:last-child::after{display:none}
.step.on::after{background:var(--cyan)}
.num{font-size:8px;font-weight:800;color:#51688F;letter-spacing:.06em;flex:none;transition:color .2s}
.step.on .num{color:var(--cyan)}
.dot{width:8px;height:8px;border-radius:50%;background:transparent;flex:none;
  border:1.5px solid rgba(143,166,212,.35);transition:all .2s}
.step.on .dot{background:var(--cyan);border-color:var(--cyan);box-shadow:0 0 10px var(--cyan)}
.step.on{color:var(--cyan)}
.mlabel{position:absolute;left:0;right:0;bottom:13px;text-align:center;
  font-size:9.5px;letter-spacing:.13em;color:var(--dim);font-weight:700}

.layer{position:absolute;inset:0;pointer-events:none;z-index:3}
.card{position:absolute;left:0;top:0;width:150px;height:92px;border-radius:7px;
  background:#EDF2F9;color:#0b1a33;padding:9px 10px;will-change:transform,opacity;
  box-shadow:0 10px 24px rgba(0,0,0,.45)}
.card .src{font-size:8px;font-weight:800;letter-spacing:.09em;color:#5A6C8C}
.card .hl{font-size:10.5px;font-weight:700;line-height:1.3;margin-top:5px}
.card .ln{height:3px;border-radius:2px;background:#C9D5E6;margin-top:5px}
.card.junk{background:#1F2D49;color:#8497BA;box-shadow:none}
.card.junk .src{color:#5C6E92}
.card.junk .hl{text-decoration:line-through;opacity:.75}
.card.junk .ln{background:#2F3F5B}
.tag{position:absolute;right:8px;bottom:7px;font-size:8px;font-weight:800;
  padding:3px 7px;border-radius:99px;letter-spacing:.05em}
.tag.skip{background:rgba(255,255,255,.08);color:#93A7CC}
.tag.keep{background:var(--cyan);color:var(--navy)}

.note{position:absolute;left:0;top:0;width:130px;height:82px;border-radius:7px;
  background:#fff;overflow:hidden;will-change:transform,opacity}
.note.fresh{box-shadow:0 12px 30px rgba(0,224,240,.3),0 0 0 1.5px var(--cyan)}
.note.addendum{box-shadow:0 12px 30px rgba(0,220,199,.3),0 0 0 1.5px var(--teal)}
.note.merge{box-shadow:0 12px 30px rgba(3,149,248,.3),0 0 0 1.5px var(--blue)}
.note .bar{height:16px;font-size:7.5px;font-weight:800;letter-spacing:.08em;padding:4px 8px;color:var(--navy)}
.note.fresh .bar{background:var(--cyan)}
.note.addendum .bar{background:var(--teal)}
.note.merge .bar{background:var(--blue)}
.note .body{padding:6px 8px}
.note .nt{font-size:9px;font-weight:700;color:#0b1a33;line-height:1.25}
.note .gs{font-size:7.5px;font-weight:700;color:#5A6C8C;margin-top:4px;letter-spacing:.05em}
.note .ln{height:3px;border-radius:2px;background:#DCE5F1;margin-top:4px}

svg{position:absolute;inset:0;width:${W}px;height:${H}px;z-index:2}
.paperlab{font-size:12.5px;fill:#CFE0FA;font-weight:800;letter-spacing:.06em}
.headlab{font-size:9.5px;fill:#93AEDC;font-weight:700}
.leaflab{font-size:10.5px;fill:#DCE8FB;font-weight:600}
.stublab{font-size:9.5px;fill:rgba(133,151,186,.5);font-weight:600}
.trunklab{font-size:10.5px;letter-spacing:.12em;fill:#7E97C6;font-weight:700}
.legend{font-size:9.5px;fill:#8FA6D4;font-weight:600}

@media (prefers-reduced-motion:reduce){
  .belt::after,.roller,.scan{animation:none}
  .morph .a,.mark .mx{animation:none;opacity:0}
  .morph .b,.mark .mk{animation:none;opacity:1}
  .rule{animation:none;width:272px}
}`;

const HTML = `
<div class="frame" part="frame"><div class="scaler"><div class="stage">
  <div class="grid"></div>
  <div class="head">
    <div class="title" role="heading" aria-level="2" aria-label="Collection becomes connection">
      <span><span class="word">Co</span><span class="morph" aria-hidden="true"
        ><i class="a">ll</i><i class="b">nn</i></span><span class="word">ection</span></span>
      <span class="mark" aria-hidden="true"><i class="mx">&#10005;</i><i class="mk">&#10003;</i></span>
    </div>
  </div>
  <div class="rule"></div>
  <div class="stats">
    <div class="stat"><b data-c="in">0</b><span>ARTICLES READ</span></div>
    <div class="stat s"><b data-c="skip">0</b><span>DROPPED</span></div>
    <div class="stat k"><b data-c="keep">0</b><span>NOTES FILED</span></div>
    <div class="stat x"><b data-c="link">0</b><span>CROSS-LINKS</span></div>
  </div>
  <svg viewBox="0 0 ${W} ${H}" aria-hidden="true"></svg>
  <div class="belt"></div>
  <div class="roller" style="left:-44px"></div><div class="roller" style="left:104px"></div>
  <div class="roller" style="left:252px"></div><div class="roller" style="left:346px"></div>
  <div class="legs" style="left:36px"></div><div class="legs" style="left:336px"></div>
  <div class="binlid"></div><div class="bin"></div>
  <div class="bintext">DROPPED</div>
  <div class="machine">
    <div class="steps">
      <div class="step"><i class="dot"></i><span class="num">01</span>CLASSIFY</div>
      <div class="step"><i class="dot"></i><span class="num">02</span>WRITE NOTE</div>
      <div class="step"><i class="dot"></i><span class="num">03</span>FRESH / ADD / MERGE</div>
      <div class="step"><i class="dot"></i><span class="num">04</span>CROSS-LINK</div>
    </div>
    <div class="mouth"></div><div class="scan"></div>
    <div class="mlabel">HUMAN-CHECKED</div>
  </div>
  <div class="layer"></div>
</div></div></div>`;

const NS = 'http://www.w3.org/2000/svg';
const el = (n, a) => { const e = document.createElementNS(NS, n);
  for (const k in a) e.setAttribute(k, a[k]); return e; };

/* ---------------- element ---------------- */

class GranvayaPipeline extends HTMLElement {
  static get observedAttributes(){ return ['chrome','links','speed','paused']; }

  constructor(){
    super();
    this.attachShadow({ mode:'open' });
    this._timers = new Set();
    this._anims  = new Set();
    this._built  = false;
  }

  connectedCallback(){
    if(!this._built){ this._build(); this._built = true; }
    this._observe();
    this._maybeRun();
  }

  disconnectedCallback(){ this._teardown(); }

  attributeChangedCallback(name){
    if(!this._built) return;
    if(name === 'speed'){ this._speed(); this._restart(); }
    if(name === 'paused') this._maybeRun();
    if(name === 'links')  this._linkMode = this.getAttribute('links') || 'fade';
  }

  /* ---- public API ---- */
  play(){ this.removeAttribute('paused'); }
  pause(){ this.setAttribute('paused',''); }

  /* ---- lifecycle helpers ---- */
  _later(fn, ms){ const t = setTimeout(()=>{ this._timers.delete(t); fn(); }, ms);
                  this._timers.add(t); return t; }
  _anim(node, frames, opts){ const a = node.animate(frames, opts);
                             this._anims.add(a); a.finished?.catch(()=>{})
                               .finally?.(()=>this._anims.delete(a)); return a; }

  _teardown(){
    this._timers.forEach(clearTimeout); this._timers.clear();
    this._anims.forEach(a=>{ try{ a.cancel(); }catch(e){} }); this._anims.clear();
    clearInterval(this._loop); this._loop = null;
    this._ro?.disconnect(); this._io?.disconnect();
    document.removeEventListener('visibilitychange', this._vis);
    this._ro = this._io = null;
  }

  _observe(){
    const frame = this.shadowRoot.querySelector('.frame');
    this._ro = new ResizeObserver(entries=>{
      // read-only: we set a transform, never a size — so this cannot re-trigger itself
      const w = entries[0].contentRect.width;
      this._scaler.style.transform = 'scale(' + (w / W) + ')';
    });
    this._ro.observe(frame);

    this._io = new IntersectionObserver(e=>{ this._onScreen = e[0].isIntersecting;
                                             this._maybeRun(); }, { threshold:0 });
    this._io.observe(this);

    this._vis = ()=> this._maybeRun();
    document.addEventListener('visibilitychange', this._vis);
  }

  _maybeRun(){
    const run = this._onScreen !== false
             && !this.hasAttribute('paused')
             && !document.hidden;
    if(run && !this._loop){
      this._tick();
      this._loop = setInterval(()=>this._tick(), this.T.cycle);
    } else if(!run && this._loop){
      clearInterval(this._loop); this._loop = null;
    }
  }

  _restart(){ if(this._loop){ clearInterval(this._loop); this._loop = null; } this._maybeRun(); }

  _speed(){
    const s = Math.max(.25, Math.min(3, parseFloat(this.getAttribute('speed')) || 1));
    this.T = { ride:4800/s, gate:700/s, pull:600/s, fly:1400/s, link:320/s, cycle:4800/s };
  }

  /* ---- build ---- */
  _build(){
    const sheet = document.createElement('style'); sheet.textContent = CSS;
    this.shadowRoot.append(sheet);
    this.shadowRoot.innerHTML += HTML;

    const $ = s => this.shadowRoot.querySelector(s);
    this._scaler = $('.scaler');
    this._layer  = $('.layer');
    this._svg    = $('svg');
    this._binlid = $('.binlid');
    this._steps  = [...this.shadowRoot.querySelectorAll('.step')];
    this._out    = {}; ['in','skip','keep','link'].forEach(k =>
      this._out[k] = this.shadowRoot.querySelector(`[data-c="${k}"]`));
    this._C = { in:0, skip:0, keep:0, link:0 };
    this._k = 0;
    this._linkMode = this.getAttribute('links') || 'fade';
    this._reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
    this._speed();
    this._buildTree();
    this._scaler.style.transform = 'scale(' + (this.clientWidth / W || 1) + ')';
  }

  _buildTree(){
    const svg = this._svg;
    this._linkG = el('g',{}); const treeG = el('g',{}), nodeG = el('g',{});
    svg.append(this._linkG, treeG, nodeG);

    // rows: every thread and every collapsed stub gets one row
    const rows = [];
    TREE.forEach(p => p.heads.forEach(h => {
      h.leaves.forEach(l => rows.push({ kind:'leaf', ref:l, head:h }));
      if(h.more) rows.push({ kind:'stub', ref:{ more:h.more }, head:h });
    }));
    const gap = (BOT - TOP) / (rows.length - 1);
    rows.forEach((r,i)=>{ r.y = TOP + i*gap; r.ref.y = r.y; });

    TREE.forEach(p=>{
      p.heads.forEach(h=>{
        const ys = rows.filter(r=>r.head===h).map(r=>r.y);
        h.y = (Math.min(...ys) + Math.max(...ys)) / 2;
      });
      const hy = p.heads.map(h=>h.y);
      p.y = (Math.min(...hy) + Math.max(...hy)) / 2;
    });

    const curve = (x0,y0,x1,y1,w,o)=> el('path',{
      d:`M ${x0} ${y0} C ${(x0+x1)/2} ${y0}, ${(x0+x1)/2} ${y1}, ${x1} ${y1}`,
      stroke:`rgba(0,224,240,${o})`, 'stroke-width':w, fill:'none', 'stroke-linecap':'round' });

    treeG.append(el('path',{ d:`M 540 362 L ${BASE.x} 362`,
      stroke:'rgba(0,224,240,.5)', 'stroke-width':5, fill:'none', 'stroke-linecap':'round' }));
    const tl = el('text',{ x:548, y:392, class:'trunklab', 'text-anchor':'middle' });
    tl.textContent = 'GS 1–4'; treeG.append(tl);

    this._byId = {};
    TREE.forEach(p=>{
      treeG.append(curve(BASE.x, BASE.y, X1, p.y, 3.4, .42));
      nodeG.append(el('circle',{ cx:X1, cy:p.y, r:5.5, fill:'#1E4F86',
        stroke:'rgba(0,224,240,.65)', 'stroke-width':1.5 }));
      const pt = el('text',{ x:X1, y:p.y-13, class:'paperlab', 'text-anchor':'middle' });
      pt.textContent = p.paper; nodeG.append(pt);

      p.heads.forEach(h=>{
        treeG.append(curve(X1, p.y, X2, h.y, 2.2, .26));
        nodeG.append(el('circle',{ cx:X2, cy:h.y, r:4, fill:'#17436F',
          stroke:'rgba(0,224,240,.45)', 'stroke-width':1.2 }));
        const ht = el('text',{ x:X2, y:h.y-11, class:'headlab', 'text-anchor':'middle' });
        ht.textContent = h.name; nodeG.append(ht);

        rows.filter(r=>r.head===h).forEach(r=>{
          if(r.kind === 'stub'){
            treeG.append(curve(X2, h.y, X3, r.y, 1.4, .1));
            nodeG.append(el('circle',{ cx:X3, cy:r.y, r:3, fill:'none',
              stroke:'rgba(143,166,212,.3)', 'stroke-width':1, 'stroke-dasharray':'2 2' }));
            const st = el('text',{ x:X3+12, y:r.y+3.5, class:'stublab' });
            st.textContent = '+ ' + r.ref.more + ' more threads'; nodeG.append(st);
            return;
          }
          const l = r.ref, live = l.preset !== false;
          const br   = curve(X2, h.y, X3, l.y, 1.8, .22);
          const halo = el('circle',{ cx:X3, cy:l.y, r:8, fill:'rgba(0,224,240,.13)' });
          const core = el('circle',{ cx:X3, cy:l.y, r:4.5, fill:'#00DCC7' });
          const lab  = el('text',{ x:X3+13, y:l.y+3.5, class:'leaflab' }); lab.textContent = l.label;
          const dots = el('g',{ transform:`translate(${X3+14},${l.y+13})` });
          treeG.append(br); nodeG.append(halo, core, lab, dots);
          if(!live) [br,halo,core,lab].forEach(e=>e.setAttribute('opacity',0));
          Object.assign(l, { br, halo, core, lab, dots, n:0, live, x:X3, base:l.adden||0 });
          for(let i=0;i<(l.adden||0);i++) this._addDot(l,false);
          this._byId[l.id] = l;
        });
      });
    });

    const lg = el('g',{ transform:'translate(612,648)' });
    [['#00E0F0','Fresh thread'],['#00DCC7','Addendum'],['#0395F8','Cross-link']].forEach((p,i)=>{
      lg.append(el('circle',{ cx:i*132, cy:-4, r:4, fill:p[0] }));
      const t = el('text',{ x:i*132+11, y:0, class:'legend' }); t.textContent = p[1]; lg.append(t);
    });
    svg.append(lg);
  }

  /* ---- animation ---- */
  _addDot(l, animate){
    const d = el('circle',{ cx:l.n*9, cy:0, r:2.6, fill:'rgba(0,220,199,.55)' });
    l.dots.append(d); l.n++;
    if(animate && !this._reduced)
      this._anim(d, [{r:0,opacity:0},{r:5,opacity:1},{r:2.6,opacity:1}],
                 { duration:620, easing:'ease-out' });
  }

  _bump(k){ this._C[k]++; this._out[k].textContent = this._C[k]; }
  _lite(i){ for(let j=0;j<=i;j++) this._steps[j].classList.add('on'); }
  _clearSteps(){ this._steps.forEach(s=>s.classList.remove('on')); }

  _arc(x0,y0,x1,y1){
    const cx=(x0+x1)/2, cy=Math.min(y0,y1)-150, f=[];
    for(let i=0;i<=26;i++){ const t=i/26, u=1-t;
      f.push({ transform:`translate(${u*u*x0+2*u*t*cx+t*t*x1}px,${u*u*y0+2*u*t*cy+t*t*y1}px) `+
               `scale(${1-.72*t}) rotate(${-12+26*t}deg)`, opacity: t>.9 ? 0 : 1 }); }
    return f;
  }

  _reveal(l){
    if(l.live) return; l.live = true;
    [l.br,l.halo,l.core,l.lab].forEach(e=>{ e.setAttribute('opacity',1);
      if(!this._reduced) this._anim(e,[{opacity:0},{opacity:1}],{duration:800,easing:'ease-out'}); });
  }

  _attach(l, kind){
    this._reveal(l);
    l.core.setAttribute('fill', kind==='fresh' ? '#00E0F0' : kind==='addendum' ? '#00DCC7' : '#0395F8');
    if(!this._reduced){
      this._anim(l.core,[{r:4.5},{r:13},{r:4.5}],{duration:700,easing:'ease-out'});
      this._anim(l.halo,[{r:8,opacity:.13},{r:34,opacity:.34},{r:8,opacity:.13}],
                 {duration:1000,easing:'ease-out'});
    }
    if(kind !== 'fresh') this._addDot(l,true);
  }

  _crossLink(from, to, delay){
    this._later(()=>{
      const a = this._byId[from], b = this._byId[to];
      if(!a || !b || !b.live) return;
      const bulge = Math.max(60, Math.abs(a.y-b.y)*0.45);
      const p = el('path',{ d:`M ${a.x} ${a.y} Q ${a.x+bulge+70} ${(a.y+b.y)/2} ${b.x} ${b.y}`,
        stroke:'#0395F8', 'stroke-width':1.6, fill:'none', 'stroke-linecap':'round' });
      this._linkG.append(p);
      this._bump('link');

      const settle = ()=>{
        p.setAttribute('stroke-dasharray','4 5'); p.setAttribute('stroke-dashoffset',0);
        if(this._linkMode === 'keep'){ p.setAttribute('opacity',.3); return; }
        this._anim(p,[{opacity:1},{opacity:.28}],{duration:1300,fill:'forwards'});
        this._later(()=>{ this._anim(p,[{opacity:.28},{opacity:0}],{duration:1500,fill:'forwards'})
          .onfinish = ()=>p.remove(); }, 2800);
      };

      if(this._reduced){ settle(); return; }
      const len = p.getTotalLength();
      p.setAttribute('stroke-dasharray',len); p.setAttribute('stroke-dashoffset',len);
      this._anim(p,[{strokeDashoffset:len},{strokeDashoffset:0}],
        {duration:900, easing:'cubic-bezier(.3,.7,.3,1)', fill:'forwards'}).onfinish = ()=>{
          settle();
          this._anim(b.core,[{r:4.5},{r:10},{r:4.5}],{duration:500,easing:'ease-out'});
        };
    }, delay);
  }

  _mkCard(d, junk){
    const c = document.createElement('div');
    c.className = 'card' + (junk ? ' junk' : '');
    c.innerHTML = `<div class="src">${d.src}</div><div class="hl">${d.hl}</div>`+
                  `<div class="ln" style="width:84%"></div><div class="ln" style="width:58%"></div>`;
    c.style.transform = `translate(${START_X}px,${CARD_Y}px)`;
    this._layer.append(c); return c;
  }

  _mkNote(d){
    const n = document.createElement('div');
    n.className = 'note ' + d.kind;
    n.innerHTML = `<div class="bar">${d.kind.toUpperCase()}</div><div class="body">`+
                  `<div class="nt">${d.note}</div><div class="gs">${d.gs}</div>`+
                  `<div class="ln" style="width:88%"></div><div class="ln" style="width:62%"></div></div>`;
    this._layer.append(n); return n;
  }

  _toBin(card){
    this._anim(this._binlid,[{transform:'rotate(0)'},{transform:'rotate(-28deg)'},{transform:'rotate(0)'}],
      {duration:560,easing:'ease-out'});
    this._anim(card,[
      {transform:`translate(${GATE_X}px,${CARD_Y}px) rotate(0)`,opacity:1},
      {transform:`translate(${GATE_X+14}px,${CARD_Y+88}px) rotate(18deg)`,opacity:.95,offset:.45},
      {transform:`translate(${GATE_X+22}px,${CARD_Y+184}px) rotate(34deg) scale(.66)`,opacity:0}
    ],{duration:950,easing:'cubic-bezier(.4,.05,.6,1)',fill:'forwards'}).onfinish = ()=>card.remove();
    this._bump('skip');
  }

  _release(item){
    const T = this.T;
    const junk = item.t === 'j', d = junk ? JUNK[item.i] : KEEP[item.i];
    const card = this._mkCard(d, junk);
    const tag = document.createElement('div');
    tag.className = 'tag ' + (junk ? 'skip' : 'keep');
    tag.textContent = junk ? 'SKIP' : 'MUST NOTE';

    this._anim(card,[{transform:`translate(${START_X}px,${CARD_Y}px)`},
                     {transform:`translate(${GATE_X}px,${CARD_Y}px)`}],
      {duration:T.ride, easing:'linear', fill:'forwards'}).onfinish = ()=>{
      // 01 CLASSIFY — verdict stamped at the gate
      this._bump('in'); this._clearSteps(); this._lite(0);
      card.append(tag);
      this._anim(tag,[{opacity:0,transform:'scale(.7)'},{opacity:1,transform:'scale(1)'}],
                 {duration:240,easing:'ease-out'});

      this._later(()=>{
        if(junk){ this._toBin(card); this._later(()=>this._clearSteps(),1100); return; }

        // 02 WRITE NOTE — card drawn into the machine
        this._lite(1);
        this._anim(card,[{transform:`translate(${GATE_X}px,${CARD_Y}px)`},
                         {transform:`translate(${IN_X}px,${CARD_Y}px)`}],
          {duration:T.pull, easing:'cubic-bezier(.5,0,.6,1)', fill:'forwards'}).onfinish = ()=>{
          card.remove();

          // 03 FRESH / ADD / MERGE — note departs for its place on the tree
          this._lite(2);
          const note = this._mkNote(d), l = this._byId[d.node], x0 = 434, y0 = CARD_Y-4;
          note.style.transform = `translate(${x0}px,${y0}px)`;
          this._anim(note, this._arc(x0,y0,l.x-14,l.y-12),
            {duration:T.fly, easing:'cubic-bezier(.2,.6,.25,1)', fill:'forwards'}).onfinish = ()=>{
              note.remove(); this._attach(l, d.kind); this._bump('keep');

              // 04 CROSS-LINK — only once the note is filed
              const links = d.links || [];
              if(!links.length){ this._later(()=>this._clearSteps(),700); return; }
              this._lite(3);
              links.forEach((t,i)=>this._crossLink(d.node, t, 200 + i*T.link));
              this._later(()=>this._clearSteps(), 200 + (links.length-1)*T.link + 1000);
            };
        };
      }, T.gate);
    };
  }

  _tick(){
    this._release(ORDER[this._k % ORDER.length]);
    this._k++;
    if(this._k % ORDER.length === 0) this._later(()=>{
      this._C = { in:0, skip:0, keep:0, link:0 };
      for(const k in this._out) this._out[k].textContent = '0';
      if(this._linkMode === 'keep'){ this._linkG.textContent = ''; }
    }, 8000);
  }
}

if(!customElements.get('granvaya-pipeline'))
  customElements.define('granvaya-pipeline', GranvayaPipeline);

export default GranvayaPipeline;
